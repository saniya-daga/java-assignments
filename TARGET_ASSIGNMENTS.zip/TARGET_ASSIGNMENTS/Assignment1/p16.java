package Assignment1;

import java.util.*;
public class p16 {
    public static void main(String args[]){
        Scanner sc= new Scanner(System.in);
        System.out.println("enter number todisplay the sequence");
        int N=sc.nextInt(),a=1,c=4;
        System.out.print(a+",");
        for(int i=1;i<N;i++){
            a=a+c;
            System.out.print(a+",");
            c=c+(((i+1)%2)*4)+4;
        }
    }
}
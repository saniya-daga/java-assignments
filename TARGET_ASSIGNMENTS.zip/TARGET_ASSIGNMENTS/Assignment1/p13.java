package Assignment1;

import java.util.*;
import static java.lang.Math.*;
public class p13 {
    public static void main(String args[]){
        Scanner sc= new Scanner(System.in);
        System.out.println("enter the length of the sequence");
        int N=sc.nextInt();
        for(int i=1;i<=N;i++){
            System.out.print((int) pow(i,i)+",");
        }
    }
}

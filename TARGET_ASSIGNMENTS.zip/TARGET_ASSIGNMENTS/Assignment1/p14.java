package Assignment1;

import java.util.*;
public class p14 {
    public static void main(String args[]){
        Scanner sc= new Scanner(System.in);
        System.out.println("enter number to display sequence");
        int n= sc.nextInt();
        int a=1, b=4, c=7;
        System.out.print(a+","+b+","+c);
        for(int i=4;i<=n;i++){
            int sum=a+b+c;
            System.out.print(","+sum);
            a=b;
            b=c;
            c=sum;
        }
    }
}

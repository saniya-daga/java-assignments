package Assignment1;

import java.util.*;
public class p3 {
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the principal,rate of interest and time period");
        int prncpl=sc.nextInt(),rate=sc.nextInt(),t=sc.nextInt();
        int amount=(prncpl*rate*t)/100;
        System.out.println("The simple interest is "+amount);
    }
}

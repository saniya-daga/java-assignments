package Assignment1;

import java.util.*;
import static java.lang.Math.*;
public class p12 {
    public static void main(String args[]){
        Scanner sc= new Scanner(System.in);
        System.out.println("enter the length of sequence");
        int N=sc.nextInt();
        for(int i=1;i<=N;i++){
            System.out.print(i*(int) pow(-1,i)+",");
        }
    }
}

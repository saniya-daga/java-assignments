package Assignment3;

import java.util.Scanner;

public class p4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("enter a character");
        char s = sc.next().charAt(0);
        System.out.println((int)s);
    }
}

package Assignment3;
import java.util.Scanner;
public class p2 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the radius and Height of the Cylinder");
        int r=sc.nextInt(), h=sc.nextInt();
        System.out.println("area of the cylinder= "+(3.14*r*r*h));
    }
}

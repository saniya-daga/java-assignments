package Assignment3;
import java.io.FileOutputStream;
import java.io.IOException;
public class p9 {
    public static void main(String[] args) {
        String s="checking if i can write into this file :)";
        try{
            FileOutputStream f=new FileOutputStream("newfile.txt"); //file object initialized
            byte a[]=s.getBytes();
            f.write(a);
            System.out.println("data written into the file");
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }
}

package Assignment3;
import java.util.Scanner;

public class p3 {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        System.out.println("enter the cost of the pen");
        int price=sc.nextInt();
        discount(price);
    }

    private static void discount(int p) {
        int discount_amount= (int) (0.12*p);
        System.out.println("discount= "+discount_amount+"\ntotal after discount= "+(p-discount_amount));
    }
}

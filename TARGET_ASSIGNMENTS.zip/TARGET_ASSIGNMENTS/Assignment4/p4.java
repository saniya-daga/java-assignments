package Assignment4;
import java.io.*;
import java.util.*;
public class p4 {
    public static void main(String[] args) {
        String s=null;
        if(s==null){
            System.out.println("string is empty");
            return;
        }
        else
            System.out.println("string isn't empty");
    }
}

package Assignment4;
import java.util.Scanner;

public class p5 {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        System.out.println("enter string");
        String s= sc.nextLine();
        System.out.println("length of string= "+s.length());
    }
}

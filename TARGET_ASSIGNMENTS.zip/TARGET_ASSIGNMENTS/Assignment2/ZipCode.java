package Assignment2;

import java.util.Scanner;

public class ZipCode
{
    public static void main(String[] args)
    {
      Scanner sc = new Scanner(System.in);
      System.out.println("\n Enter your Area's ZipCode to check:");
      int zipc = sc.nextInt();
      ZipCode zip = new ZipCode();   
      zip.NonDeliverable(zipc);                       
    }
    void NonDeliverable(int zipcode)
    {
        boolean notdeliverable = false;
        int[] non_deliverable_zip = new int[]{123, 456, 789, 321, 654, 987};          
        try
        {
            for(int i=0;i<non_deliverable_zip.length;i++)
            {
                if(zipcode==non_deliverable_zip[i])
                {
                    notdeliverable = true;
                }
            }
            if(notdeliverable)
            {
                throw new InvalidZipCodeException();     
            }
            else
            {
                System.out.println("Delivery available in your area!!"); 
            }
        }
        catch(InvalidZipCodeException ndz)
        {
            System.out.println(ndz.error_msg());               
        }
    }
    public static class InvalidZipCodeException extends Exception
    {
        String error_msg()
        {
            return("\n This is a Non Deliverable Location"); 
        }
    }
}